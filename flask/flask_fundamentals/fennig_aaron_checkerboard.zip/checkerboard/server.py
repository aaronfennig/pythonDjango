from flask import Flask, render_template
app = Flask(__name__)

@app.route("/")
def index():
    height = 8
    width = 8
    return render_template("index.html", height = height, width = width)

@app.route("/<height>/<width>")
def route_two(height, width):
    return render_template("index.html", height = int(height), width = int(width))

@app.route("/<height>/<width>/<color_one>/<color_two>")
def route_three(height, width, color_one, color_two):
    return render_template("index.html", height = int(height), width = int(width), color_one = color_one, color_two = color_two)

if __name__ == "__main__":
    app.run(debug = True)